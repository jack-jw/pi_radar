## Pi-radar desktop client
Tool for managing an external pi-radar installation

Run build.sh only when client.applescript has been changed (Pi-radar.app is precompiled)

The route database template can be downloaded through the UI when needed.
